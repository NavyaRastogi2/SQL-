# Campus Placement & Internship Management System
**DBMS Mini Project | BTech CSE | Semester 3 | Oracle SQL / PL/SQL**

## 1. Overview
A relational database for managing students, recruiting companies, job/internship openings and student applications. The project demonstrates the SQL and PL/SQL topics listed in the Amity University Rajasthan DBMS Lab Manual.

## 2. Technology
- Oracle Database (Oracle SQL / PL/SQL)
- Oracle SQL Developer or SQL*Plus
- GitHub for version control

## 3. Database tables
| Table | Purpose | Primary key |
|---|---|---|
| STUDENTS | Student academic and contact details | STUDENT_ID |
| COMPANIES | Recruiting company details | COMPANY_ID |
| JOBS | Job and internship openings | JOB_ID |
| APPLICATIONS | Student applications and their status | APPLICATION_ID |

Relationships:
- One company can post many jobs.
- One student can submit many applications.
- One job can receive many applications.
- STUDENTS and JOBS have a many-to-many relationship through APPLICATIONS.

## 4. Repository structure
```text
campus-placement-dbms/
├── README.md
└── sql/
    ├── 01_schema_ddl_constraints.sql
    ├── 02_sample_data_dml.sql
    ├── 03_functions_operators.sql
    ├── 04_joins_grouping.sql
    ├── 05_subqueries_views_indexes.sql
    ├── 06_complex_queries.sql
    ├── 07_plsql_triggers.sql
    ├── 08_transactions_demo.sql
    └── 09_admin_backup_notes.sql
```

## 5. How to run
1. Open Oracle SQL Developer and connect to your own schema.
2. Open `sql/01_schema_ddl_constraints.sql` and run it using **F5 (Run Script)**.
3. Run the remaining numbered SQL files in order.
4. Run `08_transactions_demo.sql` separately because it deliberately demonstrates COMMIT and ROLLBACK.
5. Run `09_admin_backup_notes.sql` only if you have DBA privileges; read its comments first.
6. Take screenshots of table creation, inserted records and representative query outputs for your report.

The scripts are designed for Oracle SQL. Do not run the administrative script in an ordinary student schema.

## 6. Important notes
- The core project uses four connected tables.
- `DROP TABLE` and `TRUNCATE` are destructive; examples are commented out or isolated.
- `COMMIT` makes changes permanent. `ROLLBACK` cannot undo a committed transaction.
- Oracle DDL statements generally commit implicitly. Do not expect `ROLLBACK` to undo CREATE, ALTER, DROP or TRUNCATE.
- Tablespace creation and physical backup/recovery require database-administrator access and environment-specific paths. The admin notes provide templates, not commands to run blindly.
- The trigger updates `UPDATED_ON` when an application row changes.
- The sample data is fictional.

## 7. Concepts demonstrated
DDL, DML, SELECT, constraints, scalar functions, aggregate functions, operators, set operations, joins, grouping, sorting, indexing, subqueries, views, TCL, DCL, PL/SQL and triggers.

## 8. Suggested viva explanation
The four tables are connected using primary and foreign keys. The APPLICATIONS table resolves the many-to-many relationship between students and jobs. Constraints prevent invalid data, joins combine related information, aggregate queries generate placement statistics, views simplify repeated reports, and a trigger automatically updates the modification timestamp.

## 9. Reference inspiration
This project follows common academic placement-database patterns: student/company/job/application entities, a junction/application table, constraints, joins, indexes and transaction examples. It is an original Oracle-oriented implementation aligned to the supplied lab manual, not a copy of another repository.
